package com.ajackus.library.digital_library_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalLibrarySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalLibrarySystemApplication.class, args);
	}

}
