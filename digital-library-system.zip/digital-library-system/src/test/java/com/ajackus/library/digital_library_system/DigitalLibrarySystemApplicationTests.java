package com.ajackus.library.digital_library_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalLibrarySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
